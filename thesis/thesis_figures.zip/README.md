# Thesis figure bundle

12 curated AFA figures, each as PDF and PNG at 300 dpi.

- [Browse images](GALLERY.md)
- [English captions](figures/CAPTIONS.md)
- [Exact frame selection](selection.json)
- [Example LaTeX inclusions](latex_figures.tex)
- [Full data, methodology and saved tensors](https://github.com/Giannipe/tokenizer-qualitative-temp-20261116/tree/main/thesis)

Suggested main text: M01 + M02; add M03 to discuss diffuse/overlapping slots. M04 is an alternative temporal example.

Demonstrations are recorded training examples, not closed-loop policy successes measured by this analysis.
